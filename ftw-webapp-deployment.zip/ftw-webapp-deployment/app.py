#Script to create a webapp

import pandas as pd
import streamlit as st
import joblib
import numpy as np
import time
import matplotlib.pyplot as plt


# Title of your Web Application
st.title('Sales Forecasting :sunglasses:')

# Describe your Web Application
st.write('Hello!:wave:')
st.write('We demonstrate how we can forecast advertising sales based on ad expenditure.')
st.write('Tick a box to view what is written on its right-hand side!')

# Read data
data = pd.read_csv('data/advertising_regression.csv')

# Show data
check = st.checkbox('Data')
if check:
    st.write(data)
    
# Describe Data
describe = st.checkbox('Descriptive Data')
if describe:
    st.write(data.describe())
    
# Describe Data
columns = st.checkbox('Data Columns')
if columns:
    st.write(data.columns)
    
#Data Shape
datashape = st.checkbox('Data Count')
if datashape:
    st.write(data.shape)

# Create sidebar

# Sidebar description
st.sidebar.subheader('Advertising Costs')
st.sidebar.subheader('Use the following slider bars to adjust the TV, radio or newspaper advertising costs.')

# TV slider
TV = st.sidebar.slider('TV Advertising Cost',0,300,150)

# Radio slider
radio = st.sidebar.slider('Radio Advertising Cost',0,50,25)

# Newspaper slider
newspaper = st.sidebar.slider('Newspaper Advertising Cost',0,250,125)


# Distribution of TV Advertising Cost
st.subheader('TV Advertising Cost Distribution')
hist_values = np.histogram(data.TV,bins=300,range=(0,300))[0]


#Show bar chart
st.bar_chart(hist_values)



# Distribution of Radio Advertising Cost
st.subheader('Radio Advertising Cost Distribution')
hist_values = np.histogram(data.radio,bins=300,range=(0,300))[0]


#Show bar chart
st.bar_chart(hist_values)

# Distribution of Newspaper Advertising Cost
st.subheader('Newspaper Advertising Cost Distribution')
hist_values = np.histogram(data.newspaper,bins=300,range=(0,300))[0]


#Show bar chart
st.bar_chart(hist_values)


# Load saved machine learning model
saved_model = joblib.load('advertising_model.sav')

# Predict sales using variables/features
predicted_sales = saved_model.predict([[TV, radio, newspaper]])[0]

# Print predictions
st.write(f"Predicted sales is **{predicted_sales}** dollars.")

agree = st.checkbox('Great!')
if agree:
    st.write('Thank you! Have a nice day!')

#status_text.text('Done!')
st.balloons()